(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_00929972._.js",
  "static/chunks/src_1b30d8ff._.js"
],
    source: "dynamic"
});
